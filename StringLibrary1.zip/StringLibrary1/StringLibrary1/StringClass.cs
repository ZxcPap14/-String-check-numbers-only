﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace StringLibrary1
{
    //Концерт кишлака тут?
    /// <summary>
    /// Метод, который бы определял, что строка состоит только лишь из цифр
    /// </summary>
    /// <param name="textString">
    /// </param>
    /// <returns>
    /// Метод возвращает true, если входная строка содержит только цифры
    /// </returns>
    public class StringClass
    {
        public static bool OnlyDigits(string testString)
        {
            testString = testString.Replace('.', ',');
            double number;
            bool result = double.TryParse(testString, out number);
            if (!result)
            {   
                return false;
            }
            if (string.IsNullOrEmpty(testString))
            { 
                return false; 
            }
            if (testString.Length > 10 )
            {
                return false;
            }
                
            
            return true;
        }
       
    }
}
