﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using StringLibrary1;

namespace StringLibraryTest
{
    [TestClass]
    public class CheckStringClassTest
    {
        /// <summary>
        /// Только числа
        /// </summary>
        [TestMethod]
        public void Only_Digits_ReturnTrue()
        {
            //Arrange
            string testString = "1";
            //Act
            bool result= StringClass.OnlyDigits(testString);
            //Assert
            Assert.IsTrue(result);
            
        }
        [TestMethod]
        public void scifroy_Digits_ReturnTrue()
        {
            //Arrange
            string testString = "2.345";
            //Act
            bool result = StringClass.OnlyDigits(testString);
            //Assert
            Assert.IsTrue(result);

        }
        [TestMethod]
        public void otric_Digits_ReturnTrue()
        {
            //Arrange
            string testString = "-4,34";
            //Act
            bool result = StringClass.OnlyDigits(testString);
            //Assert
            Assert.IsTrue(result);

        }
        [TestMethod]
        public void stochki_Digits_ReturnTrue()
        {
            //Arrange
            string testString = ".6";
            //Act
            bool result = StringClass.OnlyDigits(testString);
            //Assert
            Assert.IsTrue(result);

        }
        [TestMethod]
        public void zero_Digits_Returnfalse()
        {
            //Arrange
            string testString = " ";
            //Act
            bool result = StringClass.OnlyDigits(testString);
            //Assert
            Assert.IsFalse(result);

        }
        [TestMethod]
        public void many_Digits_Returnfalse()
        {
            //Arrange
            string testString = "5555555555555";
            //Act
            bool result = StringClass.OnlyDigits(testString);
            //Assert
            Assert.IsFalse(result);

        }
        [TestMethod]
        public void wrong_Digits_Returnfalse()
        {
            //Arrange
            string testString = "-5555555555555";
            //Act
            bool result = StringClass.OnlyDigits(testString);
            //Assert
            Assert.IsFalse(result);

        }
        [TestMethod]
        public void manyy_Digits_Returnfalse()
        {
            //Arrange
            string testString = "jh#";
            //Act
            bool result = StringClass.OnlyDigits(testString);
            //Assert
            Assert.IsFalse(result);

        }
        [TestMethod]
        public void centrmin_Digits_Returnfalse()
        {
            //Arrange
            string testString = "4-4";
            //Act
            bool result = StringClass.OnlyDigits(testString);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void TOCHKA_Digits_Returnfalse()
        {
            //Arrange
            string testString = ".";
            //Act
            bool result = StringClass.OnlyDigits(testString);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void bezcifer_Digits_Returnfalse()
        {
            //Arrange
            string testString = "-.-";
            //Act
            bool result = StringClass.OnlyDigits(testString);
            //Assert
            Assert.IsFalse(result);
        }
    }
}
